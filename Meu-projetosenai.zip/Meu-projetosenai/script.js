console.log("Olá mundo!!!")
console.log("Segunda linha")
console.log("terceira linha")